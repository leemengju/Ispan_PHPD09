# if-else stmt
s = int(input('Input score: '))

if s >= 60:
    print("Pass!")
else:
    print("Not pass!")

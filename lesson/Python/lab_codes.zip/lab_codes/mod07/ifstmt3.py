# if-elif-else stmt
age = int(input('Input age: '))

if age < 13:
    print('Child')
elif age < 18:
    print('Youth')
else:
    print('Adult')

# ex7-1.py

name = input('Your name please: ')

print('Hello',name)
print('Nice to meet you!')

# if stmt
s = int(input('Input score: '))

if s < 60:
    print('Put more effort!')

print('Exam socre is',s)

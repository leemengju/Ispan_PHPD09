# Function definition
def printinfo(name, age):
    print('Name:', name)
    print('Age', age)

# MAIN
# Call function
printinfo('Harris',40)
printinfo(age=20, name='Mary')

# Function definition
def area(length,width):
    return length*width

# MAIN
# Call function
result = area(15,8)
print('Area =',result)

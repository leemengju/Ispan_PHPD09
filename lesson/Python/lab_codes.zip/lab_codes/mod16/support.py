# Module defintion
def print_func(arg):
    """Print Hello message to arg argument"""
    print (__name__)
    print ('Hello :',arg)

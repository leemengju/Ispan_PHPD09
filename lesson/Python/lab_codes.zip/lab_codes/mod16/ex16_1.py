import support as up

# call defined function 
up.print_func('Rose')


# print(__name__)
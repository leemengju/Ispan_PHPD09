import bmi
#BMI.__init__
# call defined function
result = bmi.BMI(67,175)


print('175cm,67kg,BMI={:.4f}'.format(result))

# esle stmt
# using else block after for loop
s = 0
for i in range(1, 6):
    s += i
else:
    print('end of for loop!')
    print('sum =',s)

# using else blokc after while loop 
r = n = 1
while n <= 5:
    r *= n
    n += 1
else:
    print('end of while loop!')
    print('5! = ' + str(r))

      

 

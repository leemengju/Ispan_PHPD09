# continue stmt
for i in range (1, 7):
    if i % 2 == 1:
        continue
    print(i, end=' ')

print()


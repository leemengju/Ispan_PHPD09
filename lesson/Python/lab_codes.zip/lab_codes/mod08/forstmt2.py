# for stmt with range()
print('range(5) =', end=' ')
for i in range(5):
    print(i, end=' ')
print()

print('range(1,5) =', end=' ')
for i in range(1,5):
    print(i, end=' ')
print()

print('range(1,10,2) =', end=' ')
for i in range(1,11,2):
    print(i, end=' ')
print()

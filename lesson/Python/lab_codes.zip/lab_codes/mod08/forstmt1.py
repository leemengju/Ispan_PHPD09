# for stmt
m = int(input('Input a value: '))

s = 0
for i in range(1, m+1): s+=i

print('sum =',s)

# Function definition
def make_a_sound():
    """This function print duck sound"""
    print('quack')
    
# Call function
make_a_sound() 
for i in range(3):
    make_a_sound()

print(61)
print(33/4.0)
